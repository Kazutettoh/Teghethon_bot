# Copyright (C) 2019 The Raphielscape Company LLC.
#
# Licensed under the Raphielscape Public License, Version 1.b (the "License");
# you may not use this file except in compliance with the License.
#
""" Userbot initialization. """

import os

from sys import version_info
from logging import basicConfig, getLogger, INFO, DEBUG
from distutils.util import strtobool as sb

from dotenv import load_dotenv
from requests import get
from telethon import TelegramClient
from telethon.sessions import StringSession

load_dotenv("config.env")

# Logger setup:
CONSOLE_LOGGER_VERBOSE = sb(os.environ.get("CONSOLE_LOGGER_VERBOSE", "False"))


if CONSOLE_LOGGER_VERBOSE:
    basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=DEBUG,
    )
else:
    basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=INFO
    )
LOGS = getLogger(__name__)

if version_info[0] < 3 or version_info[1] < 6:
    LOGS.error(
        "You MUST have a python version of at least 3.6."
        " Multiple features depend on this. Bot quitting."
    )
    quit(1)

# Check if the config was edited by using the already used variable
CONFIG_CHECK = os.environ.get("", None)

if CONFIG_CHECK:
    LOGS.error("Please remove the line mentioned in the first hashtag from the config.env file")
    quit(1)

API_KEY = "1074290"

API_HASH = "6be9d8ef64d03758118e0865d676bcd8"

STRING_SESSION = "1BJWap1sBu4ZiUy7AAQtajrJuDUUfQGgFyjkdehmBLQUdVXaiTn37n4q9I_BaMYg2hct8YrMRQ7rc44S1ad-rlFq51sVUC02gTSIbt_OCr0XVi0W27EthkuuG5lH5cwtypk_51rEgd68YP3EMawMvKfMKssywdEFbkIU80sppAZ4VmzMSAjm_mZgfJuCctb2DMRgR3ou8abpMyc7zZoO-RsDd--gPBW0ZEqxXWMdi3fVaa24CTPUy9SC2I0Yo2RJ8kHgYIh095aKHxGj6lMt0TLWzQ5tnuhkk5H1p8JCYI_oeOwsUwUwRbpEetMwjUFyzqYapQNBIKFK-odXFhEN9SWcqKblGns8="

LOGGER_GROUP = -7282727

LOGGER = True

PM_AUTO_BAN = False

CONSOLE_LOGGER_VERBOSE =  False

DB_URI = None

SCREENSHOT_LAYER_ACCESS_KEY = None

OPEN_WEATHER_MAP_APPID = None

SUDO = None

YOUTUBE_API_KEY = None

SPOTIFY_USERNAME = None
SPOTIFY_PASS = None
SPOTIFY_BIO_PREFIX = None
DEFAULT_BIO = None

# pylint: disable=invalid-name
bot = TelegramClient(StringSession(STRING_SESSION), API_KEY, API_HASH)

if os.path.exists("learning-data-root.check"):
    os.remove("learning-data-root.check")
else:
    LOGS.info("Braincheck file does not exist, fetching...")

URL = 'https://raw.githubusercontent.com/RaphielGang/databasescape/master/learning-data-root.check'
GET = get(URL)

with open('learning-data-root.check', 'wb') as load:
    load.write(GET.content)

# Global Variables
SNIPE_TEXT = ""
COUNT_MSG = 0
BRAIN_CHECKER = []
USERS = {}
SPAM = False
WIDE_MAP = dict((i, i + 0xFEE0) for i in range(0x21, 0x7F))
WIDE_MAP[0x20] = 0x3000
COUNT_PM = {}
LASTMSG = {}
ISAFK = False
ENABLE_KILLME = True
SNIPE_ID = 0
MUTING_USERS = {}
MUTED_USERS = {}
HELPER = {}
AFKREASON = "no reason"
SPAM_ALLOWANCE = 3
SPAM_CHAT_ID = []
DISABLE_RUN = False
NOTIF_OFF = False
